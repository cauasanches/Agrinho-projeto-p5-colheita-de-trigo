let emojiX, emojiY;
let campos = [];
let mudouDeTela = false;
let tempoCidade = 35000; // 35 segundos
let tempoInicio = 0;
let tempoLimite = 35000; // ⏱️ 35 segundos
let pontos = 0;

function setup() {
  createCanvas(800, 600);
  textSize(32);
  textAlign(CENTER, CENTER);
  textSize();
  trigo = "🌾";
  iniciarJogo();
}

// Função para verificar mudar de tela
function draw() {
  if (mudouDeTela) {
    background(180, 220, 255);
    fill(80);
    rect(300, 300, 200, 300); // farinha de trigo
    fill(0);
    text("🌆 Bem-vindo à cidade! Agora temos trigo para transformar em alimentos para a população", width / 2, height / 2 - 150);
    text("Pontos: " + pontos, width / 2, height / 2);

    if (millis() - tempoCidade > 10000) {
      reiniciarJogo();
    }
  } else {
    background(100, 200, 100);

    let tempoRestante = max(0, tempoLimite - (millis() - tempoInicio));
    fill(255);
    text("⏱ Tempo: " + floor(tempoRestante / 1000) + "s", width / 2, 30);
    text("🌾 Pontos: " + pontos, width / 2, 70);

    emojiX = mouseX;
    emojiY = mouseY;

    for (let campo of campos) {
      let d = dist(emojiX, emojiY, campo.x + campo.size / 2, campo.y + campo.size / 2);

      if (d < 40 && !campo.colhido) {
        campo.colhido = true;
        pontos += 1;
      }

      if (campo.colhido) {
        fill(139, 69, 19); // marrom
      } else {
        fill(255, 255, 0); // amarelo
      }

      rect(campo.x, campo.y, campo.size, campo.size);
    }

    text("🚜", emojiX, emojiY);

    if (campos.every(c => c.colhido)) {
      mudouDeTela = true;
      tempoCidade = millis();
    }

    if (tempoRestante <= 0 && !mudouDeTela) {
      reiniciarJogo();
    }
  }
}

function iniciarJogo() {
  pontos = 0;
  campos = [];

  let cols = 6;
  let rows = 5;
  let spacingX = 120;
  let spacingY = 90;
  let startX = 80;
  let startY = 120;
  let size = 50;

  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      campos.push({
        x: startX + j * spacingX,
        y: startY + i * spacingY,
        size: size,
        colhido: false
      });
    }
  }

  tempoInicio = millis();
  mudouDeTela = false;
}

function reiniciarJogo() {
  iniciarJogo();
}
